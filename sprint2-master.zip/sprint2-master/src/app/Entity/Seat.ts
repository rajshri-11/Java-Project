export class Seat {
    constructor (public seatId : string, public seatNumber : string, public seatCategory : string, public price : string) {}
    //constructor ( public username : string, public password : string, public email : string) {}
}