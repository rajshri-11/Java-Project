export class Booking {
    constructor(public booking_id : string, public user_id : string, public eventId : string, public seatId : string){}
}