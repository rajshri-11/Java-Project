export class MatchEvent {
    constructor(public eventId : string, public title : string, public venue : string, public teamsPlaying :string, public ticketAvailability :string){}
}