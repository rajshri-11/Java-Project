export class User {
    constructor (public user_id : string, public username : string, public password : string, public email : string) {}
    //constructor ( public username : string, public password : string, public email : string) {}
}