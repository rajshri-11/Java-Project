package com.example.springbootdatajpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CricketSeatBookSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
